<?php {?>

<link rel="stylesheet" type="text/css" href="footer.css"> 


	<div class = "footer">
		
	<span > 2018 © Pinesphere Solutions Pvt Ltd
	</span>


	</div>




<?php }?>